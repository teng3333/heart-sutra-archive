# OGS Frontend Handoff Package

Claude Code / Sonnet 5 での実装用データ一式。まず `requirements.md` の
第0章(完了基準)を読んでから着手してください。

## 開く順番

1. `requirements.md` — 要件定義書本体(これが正)
2. `reference.html` — ブラウザでそのまま開ける動作サンプル。
   ローカルの `assets/` を読み込むので、このファイルと`assets/`フォルダの
   相対位置を保ったまま扱うこと
3. `docs/OGS_サイト構想書_v0.1.md` — 機構(門・床・DB)の仕様
4. `docs/Fable5_設計セッション指示書.md` — 前段の経緯(参考。デザイン部分は
   requirements.md で上書き済み)

## 未決事項(着手前に高尾へ確認)

`requirements.md` 第7章(情報設計)は未確定です。ここだけは
「無断で決めて進める」対象外なので、実装着手前に必ず確認を挟んでください。
